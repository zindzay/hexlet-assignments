package ru.hexlet.lections.trees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreesApplicationTests {

    @Test
    void contextLoads() {
    }

}
